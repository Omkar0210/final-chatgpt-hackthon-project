# Vapi CORS Fix (Serverless Proxy)

This project used to call Vapi directly from the browser, which caused CORS errors.
We added a Vercel serverless function to proxy the request server-side.

## What changed
- Added: `api/vapiProxy.ts` — forwards POST body to `https://api.vapi.ai/call/web` with `Authorization: Bearer <VAPI_API_KEY>`
- Updated: `src/components/VoiceAssistant.tsx` — removed `@vapi-ai/web` client usage and now calls `/api/vapiProxy`

## What you must do
1. In Vercel → Project → Settings → Environment Variables
   - Add **`VAPI_API_KEY`** with your Vapi secret key
2. Redeploy on Vercel
3. If you had specific assistant/call payload, fill it inside `startCall()` in `VoiceAssistant.tsx`

> Note: This proxy approach avoids browser CORS, but fine-grained controls like live mute/unmute via SDK are not wired here.
